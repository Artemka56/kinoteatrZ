import New from "../New/New";

export default function SixthBlock({arr}) {
    return (
        <div className="container" id="6">
            <New arr={arr} />
        </div>
    )
}