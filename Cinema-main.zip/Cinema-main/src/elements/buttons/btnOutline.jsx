import './btn.css'

export default function BtnOutline() {
    return (
        <div className="btn-outline">
            <button className="btnOutline">Все новинки</button>
        </div>
    )
}