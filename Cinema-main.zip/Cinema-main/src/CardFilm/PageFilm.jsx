import HeaderFull from "../elements/Headers/HeaderFull";

export default function PageFilm() {
    return (
        <HeaderFull />
    )
}